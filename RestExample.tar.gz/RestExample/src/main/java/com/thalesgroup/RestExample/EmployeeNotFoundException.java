package com.thalesgroup.RestExample;

public class EmployeeNotFoundException extends RuntimeException{
	
	public EmployeeNotFoundException(long id) {
		// TODO Auto-generated constructor stub
		super("Could not find employee" + id);
	}

}
